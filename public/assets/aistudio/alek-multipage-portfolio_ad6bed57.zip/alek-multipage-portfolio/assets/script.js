document.addEventListener('DOMContentLoaded', () => {
  if (window.lucide) lucide.createIcons();
  const menu = document.querySelector('#menu');
  const nav = document.querySelector('#navlinks');
  if (menu && nav) {
    menu.addEventListener('click', () => {
      const open = nav.classList.toggle('open');
      menu.setAttribute('aria-expanded', String(open));
      menu.setAttribute('aria-label', open ? 'Close navigation' : 'Open navigation');
      menu.innerHTML = open ? '<i data-lucide="x"></i>' : '<i data-lucide="menu"></i>';
      if (window.lucide) lucide.createIcons();
    });
    nav.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
      nav.classList.remove('open');
      menu.setAttribute('aria-expanded', 'false');
      menu.setAttribute('aria-label', 'Open navigation');
      menu.innerHTML = '<i data-lucide="menu"></i>';
      if (window.lucide) lucide.createIcons();
    }));
  }
  document.querySelectorAll('[data-filter]').forEach(button => button.addEventListener('click', () => {
    document.querySelectorAll('[data-filter]').forEach(b => {
      const active = b === button;
      b.classList.toggle('active', active);
      b.setAttribute('aria-pressed', String(active));
    });
    document.querySelectorAll('[data-category]').forEach(card => {
      card.hidden = button.dataset.filter !== 'all' && card.dataset.category !== button.dataset.filter;
    });
  }));
  document.querySelectorAll('[data-year]').forEach(el => el.textContent = new Date().getFullYear());
  const form = document.querySelector('#inquiry');
  if (form) form.addEventListener('submit', event => {
    event.preventDefault();
    const data = new FormData(form);
    const subject = 'Portfolio Inquiry — ' + data.get('service');
    const body = [
      'Hello Md. Abdul Alek,', '',
      'Name: ' + data.get('name'),
      'Email: ' + data.get('email'),
      'Service: ' + data.get('service'), '',
      'Project details:', data.get('details')
    ].join('\n');
    const status = document.querySelector('#formStatus');
    if (status) status.textContent = 'Opening your email application with the inquiry prepared. If it does not open, email contact@mdabdulalek.com.';
    window.location.href = 'mailto:contact@mdabdulalek.com?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(body);
  });
});
